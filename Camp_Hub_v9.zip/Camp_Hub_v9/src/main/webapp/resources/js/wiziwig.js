tinymce.init({
	language:'ko_KR',
  selector: 'textarea', 
});