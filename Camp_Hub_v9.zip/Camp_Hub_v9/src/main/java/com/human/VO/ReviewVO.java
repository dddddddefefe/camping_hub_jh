package com.human.VO;

public class ReviewVO {
	private int num;
	private int c_num;
	private String m_id;
	private String rv_con;
	private String nick_name;
	private String grade;
	private int star_r;
	private String indate;
	private String c_name;
	
	
	public String getIndate() {
		return indate;
	}
	public void setIndate(String indate) {
		this.indate = indate;
	}
	public int getStar_r() {
		return star_r;
	}
	public void setStar_r(int star_r) {
		this.star_r = star_r;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getC_num() {
		return c_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getRv_con() {
		return rv_con;
	}
	public void setRv_con(String rv_con) {
		this.rv_con = rv_con;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

}
