package com.human.dao;

import java.util.List;

import com.human.VO.CTypeNameVO;

public interface IF_CTypeNameDAO {

	public List<CTypeNameVO> checkType() throws Exception;
	
}
